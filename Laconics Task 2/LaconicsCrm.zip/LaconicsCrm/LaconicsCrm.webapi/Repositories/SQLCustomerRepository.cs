﻿using LaconicsCrm.webapi.Data;
using LaconicsCrm.webapi.Models.Domain;
using LaconicsCrm.webapi.Repository;
using System.Data.Common;
using Microsoft.EntityFrameworkCore;

namespace LaconicsCrm.webapi.Repositories
{
    public class SQLCustomerRepository : ICustomerRepository
    {
        private readonly LaconicsDatabaseContext laconicsDatabaseContext;
        public SQLCustomerRepository(LaconicsDatabaseContext laconicsDatabaseContext)
        {
            this.laconicsDatabaseContext = laconicsDatabaseContext;
        }

        //get all
        public async Task<List<Customer>> GetAllAsync()
        {
          return await laconicsDatabaseContext.Customers.ToListAsync();
        }

        // get by id
        public async Task<Customer> GetByIdAsync(Guid id)
        {
            return await laconicsDatabaseContext.Customers.FirstOrDefaultAsync(x => x.id == id);
        }

        //create
        public async Task<Customer> CreateAsync(Customer customer)
        {
            await laconicsDatabaseContext.Customers.AddAsync(customer);
            await laconicsDatabaseContext.SaveChangesAsync();
            return customer;
        }

        // update
        public async Task<Customer?> UpdateAsync(Guid id, Customer customer)
        {
            var existingCustomer = await laconicsDatabaseContext.Customers.FirstOrDefaultAsync(x => x.id == id);
            if (existingCustomer == null)
            {
                return null;
            }
            existingCustomer.firstname = customer.firstname;
            existingCustomer.lastname = customer.lastname;
            existingCustomer.email = customer.email;

            await laconicsDatabaseContext.SaveChangesAsync();
            return existingCustomer;
        }

        // delete
        public async Task<Customer?> DeleteAsync(Guid id)
        {
            var existingCustomer = await laconicsDatabaseContext.Customers.FirstOrDefaultAsync(x => x.id == id);
            if (existingCustomer == null)
            {
                return null;
            }

            laconicsDatabaseContext.Remove(existingCustomer);
            await laconicsDatabaseContext.SaveChangesAsync();
            return existingCustomer;
        }
    

    }
}
