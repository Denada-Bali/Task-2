﻿using LaconicsCrm.webapi.Data;
using LaconicsCrm.webapi.Models.Domain;
using LaconicsCrm.webapi.Repository;
using Microsoft.EntityFrameworkCore;

namespace LaconicsCrm.webapi.Repositories
{
    public class SQLProductRepository : IProductRepository
    {

        private readonly LaconicsDatabaseContext laconicsDatabaseContext;
        public SQLProductRepository(LaconicsDatabaseContext laconicsDatabaseContext)
        {
            this.laconicsDatabaseContext = laconicsDatabaseContext;
        }

        // create
        public async Task<Product> CreateAsync(Product product)
        {
            await laconicsDatabaseContext.products.AddAsync(product);
            await laconicsDatabaseContext.SaveChangesAsync();
            return product;
        }


        //delete
        public async Task<Product?> DeleteAsync(Guid id)
        {
            var existingProduct = await laconicsDatabaseContext.products.FirstOrDefaultAsync(x => x.productId == id);
            if (existingProduct == null)
            {
                return null;
            }
            laconicsDatabaseContext.Remove(existingProduct);
            await laconicsDatabaseContext.SaveChangesAsync();
            return existingProduct;
        }


        // get all
        public async Task<List<Product>> GetAllAsync()
        {
            return await laconicsDatabaseContext.products.ToListAsync();
        }




        //get by id
        public async Task<Product> GetByIdAsync(Guid id)
        {
            return await laconicsDatabaseContext.products.FirstOrDefaultAsync(x => x.productId == id);
        }

   

        


        //update
        public async Task<Product?> UpdateAsync(Guid id, Product product)
        {
            var existingProduct = await laconicsDatabaseContext.products.FirstOrDefaultAsync(x => x.productId == id);
            if (existingProduct == null)
            {
                return null;
            }
            existingProduct.productName = product.productName;
            existingProduct.price = product.price;

            await laconicsDatabaseContext.SaveChangesAsync();
            return existingProduct;
        }
    }
}
