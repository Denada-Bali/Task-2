﻿using LaconicsCrm.webapi.Data;
using LaconicsCrm.webapi.Models.Domain;
using LaconicsCrm.webapi.Repository;
using Microsoft.EntityFrameworkCore;

namespace LaconicsCrm.webapi.Repositories
{
    public class SQLOrderRepository : IOrderRepository
    {
        private readonly LaconicsDatabaseContext laconicsDatabaseContext;
        public SQLOrderRepository(LaconicsDatabaseContext laconicsDatabaseContext)
        {
            this.laconicsDatabaseContext = laconicsDatabaseContext;
        }


        public async Task<List<Order>> GetAllAsync()
        {
            return await laconicsDatabaseContext.Orders.ToListAsync();
        }


        public async Task<Order> GetByIdAsync(Guid id)
        {
            return await laconicsDatabaseContext.Orders.FirstOrDefaultAsync(x => x.orderId == id);
        }

        public async Task<List<Order>> GetByCustomerIdAsync(Guid id)
        {
           
            return await laconicsDatabaseContext.Orders.Where(x => x.customerId == id).ToListAsync();
        }

        public async Task<List<Product>> GetProductFromOrderIdAsync(Guid id)
        {

            return await laconicsDatabaseContext.products.Where(x => x.orderId == id).ToListAsync();
        }



        public async Task<Order> CreateAsync(Order order)
        {
            await laconicsDatabaseContext.Orders.AddAsync(order);
            await laconicsDatabaseContext.SaveChangesAsync();
            return order;
        }


        public async Task<Order?> UpdateAsync(Guid id, Order order)
        {
            var existingOrder = await laconicsDatabaseContext.Orders.FirstOrDefaultAsync(x => x.orderId == id);
            if (existingOrder == null)
            {
                return null;
            }
            existingOrder.date = order.date;
            existingOrder.totalAmount = order.totalAmount;

            await laconicsDatabaseContext.SaveChangesAsync();
            return existingOrder;
        }

        public async Task<Order?> DeleteAsync(Guid id)
        {
            var existingOrder = await laconicsDatabaseContext.Orders.FirstOrDefaultAsync(x => x.orderId == id);
            if (existingOrder == null)
            {
                return null;
            }

            laconicsDatabaseContext.Remove(existingOrder);
            await laconicsDatabaseContext.SaveChangesAsync();
            return existingOrder;
        }

    }
}
