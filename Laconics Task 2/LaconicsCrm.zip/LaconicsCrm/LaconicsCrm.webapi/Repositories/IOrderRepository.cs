﻿using LaconicsCrm.webapi.Models.Domain;

namespace LaconicsCrm.webapi.Repository
{
    public interface IOrderRepository
    {
        Task<List<Order>> GetAllAsync();
        Task<Order> GetByIdAsync(Guid id);
        Task<List<Order>> GetByCustomerIdAsync(Guid id);
        Task<List<Product>> GetProductFromOrderIdAsync(Guid id);
        Task<Order> CreateAsync(Order order);
        Task<Order?> UpdateAsync(Guid id, Order order);
        Task<Order?> DeleteAsync(Guid id);
    }
}
