﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LaconicsCrm.webapi.Migrations
{
    /// <inheritdoc />
    public partial class ModelsRelationship : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<Guid>(
                name: "orderId",
                table: "products",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "productId",
                table: "Customers",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_products_orderId",
                table: "products",
                column: "orderId");

            migrationBuilder.CreateIndex(
                name: "IX_Customers_productId",
                table: "Customers",
                column: "productId");

            migrationBuilder.AddForeignKey(
                name: "FK_Customers_products_productId",
                table: "Customers",
                column: "productId",
                principalTable: "products",
                principalColumn: "productId");

            migrationBuilder.AddForeignKey(
                name: "FK_products_Orders_orderId",
                table: "products",
                column: "orderId",
                principalTable: "Orders",
                principalColumn: "orderId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Customers_products_productId",
                table: "Customers");

            migrationBuilder.DropForeignKey(
                name: "FK_products_Orders_orderId",
                table: "products");

            migrationBuilder.DropIndex(
                name: "IX_products_orderId",
                table: "products");

            migrationBuilder.DropIndex(
                name: "IX_Customers_productId",
                table: "Customers");

            migrationBuilder.DropColumn(
                name: "orderId",
                table: "products");

            migrationBuilder.DropColumn(
                name: "productId",
                table: "Customers");
        }
    }
}
