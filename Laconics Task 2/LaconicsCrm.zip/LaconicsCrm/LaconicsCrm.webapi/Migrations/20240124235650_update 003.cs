﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LaconicsCrm.webapi.Migrations
{
    /// <inheritdoc />
    public partial class update003 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
