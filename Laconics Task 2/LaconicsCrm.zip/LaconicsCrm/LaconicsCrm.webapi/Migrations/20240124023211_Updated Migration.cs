﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LaconicsCrm.webapi.Migrations
{
    /// <inheritdoc />
    public partial class UpdatedMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Customers_products_productId",
                table: "Customers");

            migrationBuilder.DropIndex(
                name: "IX_Customers_productId",
                table: "Customers");

            migrationBuilder.DropColumn(
                name: "productId",
                table: "Customers");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<Guid>(
                name: "productId",
                table: "Customers",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Customers_productId",
                table: "Customers",
                column: "productId");

            migrationBuilder.AddForeignKey(
                name: "FK_Customers_products_productId",
                table: "Customers",
                column: "productId",
                principalTable: "products",
                principalColumn: "productId");
        }
    }
}
