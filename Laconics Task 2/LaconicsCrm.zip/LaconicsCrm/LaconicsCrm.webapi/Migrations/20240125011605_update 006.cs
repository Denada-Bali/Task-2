﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LaconicsCrm.webapi.Migrations
{
    /// <inheritdoc />
    public partial class update006 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_products_Orders_orderId",
                table: "products");

            migrationBuilder.AlterColumn<Guid>(
                name: "orderId",
                table: "products",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"),
                oldClrType: typeof(Guid),
                oldType: "uniqueidentifier",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_products_Orders_orderId",
                table: "products",
                column: "orderId",
                principalTable: "Orders",
                principalColumn: "orderId",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_products_Orders_orderId",
                table: "products");

            migrationBuilder.AlterColumn<Guid>(
                name: "orderId",
                table: "products",
                type: "uniqueidentifier",
                nullable: true,
                oldClrType: typeof(Guid),
                oldType: "uniqueidentifier");

            migrationBuilder.AddForeignKey(
                name: "FK_products_Orders_orderId",
                table: "products",
                column: "orderId",
                principalTable: "Orders",
                principalColumn: "orderId");
        }
    }
}
